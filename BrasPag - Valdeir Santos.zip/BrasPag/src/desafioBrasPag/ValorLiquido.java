package desafioBrasPag;
import java.util.Scanner;
      
public class ValorLiquido {
    public static void main(String[] args){
       int total, score; 
       double percentage;
       Scanner inputNumScanner = new Scanner(System.in);
       
       
                //ADQUIRENTE A: CART�O VISA CR�DITO
       System.out.println("==== Adquirente A ==== \n");
       System.out.println("Cart�o: Visa_Cr�dito");
       System.out.println("Digite o valor total ou m�ximo:");    
       total = inputNumScanner.nextInt();
       
       percentage = total - 2.25;
	   System.out.println("A porcentagem �: 2.25");
	     
       System.out.println("O valor l�quido �: " + percentage);
       score = inputNumScanner.nextInt();
    

                    //CART�O VISA D�BITO                   
       System.out.println("==== Adquirente A ==== \n");
       System.out.println("Cart�o: Visa_D�bito");
       System.out.println("Digite o valor total ou m�ximo:");    
       total = inputNumScanner.nextInt();
       
       percentage = total - 2.00;
       System.out.println("A porcentagem �: 2.00");
       
       System.out.println("O valor l�quido �: " + percentage);
       score = inputNumScanner.nextInt();
       
       
                   //CART�O MASTER CR�DITO
       System.out.println("==== Adquirente A ==== \n");
       System.out.println("Cart�o: Master_Cr�dito");
       System.out.println("Digite o valor total ou m�ximo:");    
       total = inputNumScanner.nextInt();
       
       percentage = total - 2.35;
       System.out.println("A porcentagem �: 2.35");
       
       System.out.println("O valor l�quido �: " + percentage);
       score = inputNumScanner.nextInt();
       
       
                  //CART�O MASTER D�BITO
       System.out.println("==== Adquirente A ==== \n");
       System.out.println("Cart�o: Master_D�bito");
       System.out.println("Digite o valor total ou m�ximo:");    
       total = inputNumScanner.nextInt();
       
       percentage = total - 1.98;
       System.out.println("A porcentagem �: 1.98");
       
       System.out.println("O valor l�quido �: " + percentage);
       score = inputNumScanner.nextInt();
       
       
                //ADQUIRENTE B: CART�O VISA CR�DITO
       System.out.println("==== Adquirente B ==== \n");
       System.out.println("Cart�o: Visa_Cr�dito");
       System.out.println("Digite o valor total ou m�ximo:");    
       total = inputNumScanner.nextInt();
       
       percentage = total - 2.50;
       System.out.println("A porcentagem �: 2.50");
       
       System.out.println("O valor l�quido �: " + percentage);
       score = inputNumScanner.nextInt();
       
       
                     //CART�O VISA D�BITO
       System.out.println("==== Adquirente B ==== \n");
       System.out.println("Cart�o: Visa_D�bito");
       System.out.println("Digite o valor total ou m�ximo:");    
       total = inputNumScanner.nextInt();
       
       percentage = total - 2.08;
       System.out.println("A porcentagem �: 2.08");
       
       System.out.println("O valor l�quido �: " + percentage);
       score = inputNumScanner.nextInt();
       
       
                    //CART�O MASTER CR�DITO
       System.out.println("==== Adquirente B ==== \n");
       System.out.println("Cart�o: Master_Cr�dito");
       System.out.println("Digite o valor total ou m�ximo:");    
       total = inputNumScanner.nextInt();
       
       percentage = total - 2.65;
       System.out.println("A porcentagem �: 2.65");
       
       System.out.println("O valor l�quido �: " + percentage);
       score = inputNumScanner.nextInt();
       
       
                   //CART�O MASTER D�BITO
       System.out.println("==== Adquirente B ==== \n");
       System.out.println("Cart�o: Master_D�bito");
       System.out.println("Digite o valor total ou m�ximo:");    
       total = inputNumScanner.nextInt();
       
       percentage = total - 1.75;
       System.out.println("A porcentagem �: 1.75");
       
       System.out.println("O valor l�quido �: " + percentage);
       score = inputNumScanner.nextInt();
       
       
                   //ADQUIRENTE C: CART�O VISA CR�DITO
       System.out.println("==== Adquirente C ==== \n");
       System.out.println("Cart�o: Visa_Cr�dito");
       System.out.println("Digite o valor total ou m�ximo:");    
       total = inputNumScanner.nextInt();
       
       percentage = total - 2.75;
       System.out.println("A porcentagem �: 2.75");
       
       System.out.println("O valor l�quido �: " + percentage);
       score = inputNumScanner.nextInt();
       
       
                    //CART�O VISA D�BITO
       System.out.println("==== Adquirente C ==== \n");
       System.out.println("Cart�o: Visa_D�bito");
       System.out.println("Digite o valor total ou m�ximo:");    
       total = inputNumScanner.nextInt();
       
       percentage = total - 2.16;
       System.out.println("A porcentagem �: 2.16");
       
       System.out.println("O valor l�quido �: " + percentage);
       score = inputNumScanner.nextInt();
       
       
                   //CART�O MASTER CR�DITO
       System.out.println("==== Adquirente C ==== \n");
       System.out.println("Cart�o: Master_Cr�dito");
       System.out.println("Digite o valor total ou m�ximo:");    
       total = inputNumScanner.nextInt();
       
       percentage = total - 3.10;
       System.out.println("A porcentagem �: 3.10");
       
       System.out.println("O valor l�quido �: " + percentage);
       score = inputNumScanner.nextInt();
       
       
                  //CART�O MASTER D�BITO
       System.out.println("==== Adquirente C ==== \n");
       System.out.println("Cart�o: Master_D�bito");
       System.out.println("Digite o valor total ou m�ximo:");    
       total = inputNumScanner.nextInt();
       
       percentage = total - 1.58;
       System.out.println("A porcentagem �: 1.58");
       
       System.out.println("O valor l�quido �: " + percentage);
       score = inputNumScanner.nextInt();
   
    }
}
    

    
       

